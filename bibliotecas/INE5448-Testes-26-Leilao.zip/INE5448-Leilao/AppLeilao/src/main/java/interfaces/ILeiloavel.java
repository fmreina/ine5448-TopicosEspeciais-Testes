package interfaces;

public interface ILeiloavel {
	public String getNome();

	public String getDescricao();

	public String getCpfLeiloador();

	public Double getValorUltimoLance();
}