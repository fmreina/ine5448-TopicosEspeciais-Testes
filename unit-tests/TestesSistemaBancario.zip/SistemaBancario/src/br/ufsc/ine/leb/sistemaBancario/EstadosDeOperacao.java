package br.ufsc.ine.leb.sistemaBancario;

public enum EstadosDeOperacao {

	SUCESSO, SALDO_INSUFICIENTE, MOEDA_INVALIDA

}
